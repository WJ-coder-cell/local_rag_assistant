import streamlit as st
import requests

st.set_page_config(page_title="📚私有知识库RAG问答助手", layout="wide")
st.title("📚 私有知识库RAG问答助手")

# 初始化对话历史
if "history" not in st.session_state:
    st.session_state["history"] = []

# 文件上传
uploaded_file = st.file_uploader("上传文档 PDF / TXT / MD", type=["pdf", "txt", "md"])
if uploaded_file:
    resp = requests.post("http://127.0.0.1:8000/upload_file", files={"file": uploaded_file})
    data = resp.json()
    if data["code"] == 0:
        st.success(f"✅文档入库完成，切片数：{data['chunk_num']}")

# 渲染历史对话
for item in st.session_state["history"]:
    st.chat_message("user").write(item["q"])
    st.chat_message("assistant").write(item["a"])

# 用户输入提问
question = st.chat_input("请提问...")
if question:
    st.chat_message("user").write(question)
    with st.spinner("思考中..."):
        r = requests.post("http://127.0.0.1:8000/chat", params={"query": question})
        res_data = r.json()
        ans = res_data["answer"]
        srcs = res_data["source_documents"]
        st.chat_message("assistant").write(ans)
        st.markdown("**参考片段：**")
        for s in srcs:
            st.code(s, language="text")
    st.session_state["history"].append({"q": question, "a": ans})

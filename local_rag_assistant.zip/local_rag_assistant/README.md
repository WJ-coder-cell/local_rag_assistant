# 📚 本地私有知识库RAG问答助手
> 本地化RAG+多轮对话+混合检索私有文档问答系统。

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/release/python‑3100/)

## ✨功能特性
- ✅支持PDF/TXT/MD文档解析入库
- ✅BM25关键词检索 + 向量RRF加权混合检索，解决纯向量召回丢失关键词
- ✅BGE‑Reranker重排序过滤检索噪声
- ✅多轮对话记忆，支持上下文问答
- ✅抽象向量存储层：Chroma本地开发，可切换Milvus生产
- ✅FastAPI RESTful接口，Streamlit网页交互
- ✅返回原始参考片段抑制大模型幻觉
- ✅兼容Ollama本地开源大模型，兼容OpenAI接口格式
- ✅RAGAS框架问答效果量化评估

## 🛠技术栈
Python3.10、FastAPI、LangChain、Chroma/Milvus、BGE、Ollama、Streamlit、RAGAS、rank‑bm25

## 📋环境准备
1. 安装 Ollama https://ollama.com/
```bash
ollama pull qwen:7b‑instruct

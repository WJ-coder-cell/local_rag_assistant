from datasets import Dataset
from ragas import evaluate
from ragas.metrics import answer_relevancy, context_recall

# 将下面替换为你自己的测试用例
test_data = {
    "question": ["测试你的知识库的问题"],
    "ground_truth": ["期望标准答案"],
    "contexts": [["检索返回的上下文片段"]]
}

ds = Dataset.from_dict(test_data)
result = evaluate(ds, metrics=[answer_relevancy, context_recall])
print(result)

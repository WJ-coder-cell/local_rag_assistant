import os

# 文本切分参数
CHUNK_SIZE = 512
CHUNK_OVERLAP = 80
RETRIEVE_TOP_K = 4
RERANK_TOP_N = 2

# 模型配置
EMBEDDING_MODEL_NAME = "BAAI/bge-small-zh"
RERANK_MODEL_NAME = "BAAI/bge-reranker-base-zh"
OLLAMA_MODEL = "qwen:7b-instruct"

# 路径配置
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VECTOR_DB_PATH = os.path.join(BASE_DIR, "vector_db")
DATA_FOLDER = os.path.join(BASE_DIR, "data")

os.makedirs(DATA_FOLDER, exist_ok=True)
os.makedirs(VECTOR_DB_PATH, exist_ok=True)

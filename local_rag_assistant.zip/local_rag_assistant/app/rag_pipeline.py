import os
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceBgeEmbeddings
from langchain_community.llms import Ollama
from langchain.retrievers import ContextualCompressionRetriever, EnsembleRetriever
from langchain.retrievers.document_compressors import CrossEncoderReranker
from langchain_community.cross_encoders import HuggingFaceCrossEncoder
from langchain_community.retrievers import BM25Retriever
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain

from app.config import *

# Embedding模型初始化
embedding = HuggingFaceBgeEmbeddings(
    model_name=EMBEDDING_MODEL_NAME,
    model_kwargs={"device": "cpu"}
)

# 向量数据库Chroma
vectordb = Chroma(
    persist_directory=VECTOR_DB_PATH,
    embedding_function=embedding
)

# 全局缓存文档，用于BM25检索，重启程序会丢失
all_split_docs = []

# Reranker重排序模型
model_rerank = HuggingFaceCrossEncoder(model_name=RERANK_MODEL_NAME, model_kwargs={"device": "cpu"})
compressor = CrossEncoderReranker(model=model_rerank, top_n=RERANK_TOP_N)


def load_document(file_path: str):
    """文档加载、切分、存入向量库，同时维护文档列表给BM25"""
    global all_split_docs
    if file_path.endswith(".pdf"):
        loader = PyPDFLoader(file_path)
    elif file_path.endswith(".txt") or file_path.endswith(".md"):
        loader = TextLoader(file_path, encoding="utf-8")
    else:
        raise Exception("仅支持pdf/txt/md格式文档")

    docs = loader.load()
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP
    )
    split_docs = splitter.split_documents(docs)
    vectordb.add_documents(split_docs)
    vectordb.persist()
    all_split_docs.extend(split_docs)
    return len(split_docs)


def get_chat_chain():
    """构建：BM25+向量RRF混合检索 + Rerank重排序 + 多轮会话记忆"""
    vec_retriever = vectordb.as_retriever(search_kwargs={"k": RETRIEVE_TOP_K})
    bm25_retriever = BM25Retriever.from_documents(all_split_docs)
    bm25_retriever.k = RETRIEVE_TOP_K

    # RRF加权融合检索结果
    ensemble_retriever = EnsembleRetriever(
        retrievers=[bm25_retriever, vec_retriever],
        weights=[0.4, 0.6]
    )

    compression_retriever = ContextualCompressionRetriever(
        base_retriever=ensemble_retriever,
        base_compressor=compressor
    )

    llm = Ollama(model=OLLAMA_MODEL)
    memory = ConversationBufferMemory(
        memory_key="chat_history",
        return_messages=True,
        output_key="answer"
    )

    chat_chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=compression_retriever,
        memory=memory,
        return_source_documents=True
    )
    return chat_chain

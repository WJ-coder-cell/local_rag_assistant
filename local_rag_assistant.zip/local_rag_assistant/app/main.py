from fastapi import FastAPI, UploadFile, File
import os
from app.rag_pipeline import load_document, get_chat_chain
from app.config import DATA_FOLDER

app = FastAPI(title="RAG私有知识库API")


@app.post("/upload_file")
async def upload_file(file: UploadFile = File(...)):
    save_path = os.path.join(DATA_FOLDER, file.filename)
    with open(save_path, "wb") as f:
        f.write(await file.read())
    chunk_num = load_document(save_path)
    return {"code": 0, "msg": "文档入库成功", "chunk_num": chunk_num}


@app.post("/chat")
async def chat(query: str):
    chain = get_chat_chain()
    res = chain.invoke({"question": query})
    sources = [doc.page_content for doc in res["source_documents"]]
    return {
        "answer": res["answer"],
        "source_documents": sources
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

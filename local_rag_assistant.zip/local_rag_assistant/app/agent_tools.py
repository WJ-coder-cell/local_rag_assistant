from langchain.tools import tool
import datetime


@tool
def get_current_time():
    """获取当前系统时间，用户询问时间的时候调用"""
    now = datetime.datetime.now()
    return f"当前时间：{now.strftime('%Y‑%m‑%d %H:%M:%S')}"


@tool
def calculator(expression: str):
    """数学计算器，输入数学表达式，例如：2+3*5"""
    return str(eval(expression))


tool_list = [get_current_time, calculator]
